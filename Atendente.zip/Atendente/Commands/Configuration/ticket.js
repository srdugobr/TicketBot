const Discord = require("discord.js");
const config = require('../../config.json');

module.exports = {
    name: "ticket",
    description: "📱 [Configuração] Utilize para enviar uma embed para abrir um ticket",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) return interaction.reply({
            content: `**<:cancelar:1110144176999387166> | ${interaction.user}, Você precisa da permissão \`ADMNISTRATOR\` para usar este comando!**`,
            ephemeral: true,
        })

        await interaction.channel.send({
            embeds: [
                new Discord.EmbedBuilder()
                    .setColor(config.embeds_color.embed_invisible)
                    .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: '<a:Sg22_WumpusWavesHi:1114417697330036836> | Informações', value: `> **Se Você Estiver Precisando De Ajuda Clique No Botão Abaixo**` },
                        { name: '<:suporte:1110641540344320131> | Horário De Atendimento', value: `> (Segunda/Sexta) **14:00 até as 00:00 Horas** (Sábado/Domingo) **12:00 até as 00:00 Horas**` }
                    )
                    .setImage("https://cdn.discordapp.com/attachments/1106673394189074543/1115415278201884773/721_Sem_Titulo_20230525075532.png")
                    .setFooter({ text: `Copyright © Lunnar Stock` })
            ],
            components: [
                new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('start_ticket')
                            .setLabel('Abrir Ticket')
                            .setEmoji('<:foguete_paracima:1115414894095908864>')
                            .setStyle(2)
                    )
            ]
        });

        interaction.reply({
            embeds: [
                new Discord.EmbedBuilder()
                    .setColor(config.embeds_color.embed_success)
                    .setDescription(`<:confirmar:1110144185643847691> | Embed enviada com sucesso!`)
            ],
            ephemeral: true
        })
    }
}