1 - Preencha todas as informações do arquivo config.json!
2 - Iniciar o arquivo `install.bat` e aguardar finalizar!
3 - Iniciar o arquivo `start.bat` e pronto so utilizar!

Copyright ©️ Zoom System 2022 - 2023